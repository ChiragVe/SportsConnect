package com.app.banking;

 

//import custom_exceptions.
//import static utils.BankingValidations.validateBalance;

// Enum for account types
public enum AccountType {
    SAVINGS(1000), CURRENT(5000);

    private final double minBalance;

    AccountType(double minBalance) {
        this.minBalance = minBalance;
    }

    public double getMinBalance() {
        return minBalance;
    }
}