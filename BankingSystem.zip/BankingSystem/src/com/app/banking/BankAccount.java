package com.app.banking;

import java.time.LocalDate;

public class BankAccount {
    private int acctNo;
    private String firstName;
    private String lastName;
    private AccountType acType;
    private LocalDate dob;
    private LocalDate creationDate;
    private double balance;

    // Constructor to initialize the state of the account
    public BankAccount(int acctNo, String firstName, String lastName, AccountType acType, LocalDate dob,
                       double balance) {
        this.acctNo = acctNo;
        this.firstName = firstName;
        this.lastName = lastName;
        this.acType = acType;
        this.dob = dob;
        this.creationDate = LocalDate.now();
        this.balance = balance;
    }

    // Override toString to return account details
    @Override
    public String toString() {
        return "BankAccount [acctNo=" + acctNo + ", firstName=" + firstName + ", lastName=" + lastName +
                ", acType=" + acType + ", dob=" + dob + ", creationDate=" + creationDate + ", balance=" + balance + "]";
    }

    // Business logic method - deposit
    public void deposit(double amount) {
        this.balance += amount;
    }

    // Withdraw with exception handling
    public void withdraw(double amount)  {
        if (amount <= 0) {
  System.out.println("Invalid amount for withdrawal: " + amount);
        }

        if (balance - amount < acType.getMinBalance()) {
        	System.out.println("Insufficient balance for withdrawal");
        }

        this.balance -= amount;
    }

    // Funds transfer with exception handling
    public void transferFunds(BankAccount dest, double transferAmount) {
        if (transferAmount <= 0) {
        	System.out.println("Invalid amount for funds transfer: " + transferAmount);
        }

        if (balance - transferAmount < acType.getMinBalance()) {
        	System.out.println("Insufficient balance for funds transfer");
        }

        this.withdraw(transferAmount);
        dest.deposit(transferAmount);
    }

    // Getters
    public LocalDate getDob() {
        return dob;
    }

    public double getBalance() {
        return balance;
    }

    public int getAcctNo() {
        return acctNo;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public AccountType getAcType() {
        return acType;
    }

    public LocalDate getCreationDate() {
        return creationDate;
    }
}
