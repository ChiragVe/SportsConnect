package com.app.tester;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import com.app.banking.AccountType;
import com.app.banking.BankAccount;

public class BankAccountTester {
    private static Map<Integer, BankAccount> accountsMap = new HashMap<>();
    private static int accountCounter = 1000;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\nMenu:");
            System.out.println("1. Create Account");
            System.out.println("2. Deposit");
            System.out.println("3. Withdraw");
            System.out.println("4. Transfer Funds");
            System.out.println("5. Print Account Details");
            System.out.println("0. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    createAccount(scanner);
                    break;
                case 2:
                    performDeposit(scanner);
                    break;
                case 3:
                    performWithdrawal(scanner);
                    break;
                case 4:
                    performTransfer(scanner);
                    break;
                case 5:
                    printAccountDetails(scanner);
                    break;
                case 0:
                    System.out.println("Exiting program...");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
                    break;
            }
        } while (choice != 0);

        scanner.close();
    }

    private static void createAccount(Scanner scanner) {
        System.out.print("Enter first name: ");
        String firstName = scanner.next();
        System.out.print("Enter last name: ");
        String lastName = scanner.next();
        System.out.print("Enter date of birth (YYYY-MM-DD): ");
        LocalDate dob = LocalDate.parse(scanner.next());
        System.out.print("Enter initial balance: ");
        double initialBalance = scanner.nextDouble();

        System.out.println("Select Account Type:");
        for (AccountType type : AccountType.values()) {
            System.out.println((type.ordinal() + 1) + ". " + type.name());
        }
        System.out.print("Enter your choice: ");
        int typeChoice = scanner.nextInt();

        AccountType accountType;
        try {
            accountType = AccountType.values()[typeChoice - 1];
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Invalid account type choice. Defaulting to Savings.");
            accountType = AccountType.SAVINGS;
        }

        BankAccount newAccount = new BankAccount(++accountCounter, firstName, lastName, accountType, dob, initialBalance);
        accountsMap.put(newAccount.getAcctNo(), newAccount);
        System.out.println("Account created successfully with account number: " + newAccount.getAcctNo());
    }

    private static void performDeposit(Scanner scanner) {
        System.out.print("Enter account number: ");
        int accountNo = scanner.nextInt();
        BankAccount account = accountsMap.get(accountNo);
        if (account != null) {
            System.out.print("Enter deposit amount: ");
            double amount = scanner.nextDouble();
            account.deposit(amount);
            System.out.println("Deposit successful. Updated balance: " + account.getBalance());
        } else {
            System.out.println("Account not found.");
        }
    }

    private static void performWithdrawal(Scanner scanner) {
        System.out.print("Enter account number: ");
        int accountNo = scanner.nextInt();
        BankAccount account = accountsMap.get(accountNo);
        if (account != null) {
            System.out.print("Enter withdrawal amount: ");
            double amount = scanner.nextDouble();
            account.withdraw(amount);
            System.out.println("Withdrawal successful. Updated balance: " + account.getBalance());
        } else {
            System.out.println("Account not found.");
        }
    }

    private static void performTransfer(Scanner scanner) {
        System.out.print("Enter source account number: ");
        int sourceAccountNo = scanner.nextInt();
        BankAccount sourceAccount = accountsMap.get(sourceAccountNo);
        if (sourceAccount != null) {
            System.out.print("Enter destination account number: ");
            int destAccountNo = scanner.nextInt();
            BankAccount destAccount = accountsMap.get(destAccountNo);
            if (destAccount != null) {
                System.out.print("Enter transfer amount: ");
                double amount = scanner.nextDouble();
                sourceAccount.transferFunds(destAccount, amount);
                System.out.println("Funds transfer successful.");
            } else {
                System.out.println("Destination account not found.");
            }
        } else {
            System.out.println("Source account not found.");
        }
    }

    private static void printAccountDetails(Scanner scanner) {
        System.out.print("Enter AccountNo ");
        int accountNo = scanner.nextInt();
        BankAccount account = accountsMap.get(accountNo);
        if (account != null) {
            System.out.println(account);
        } else {
            System.out.println("Account not found.");
        }
    }
}
